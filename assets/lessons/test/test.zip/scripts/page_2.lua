print("ifucking hate")
label = createLabel(WIDTH / 2, HEIGHT / 4, "Second Page.", 24)
add(label)